package testgenetic;

import java.util.ArrayList;

public class Testgenetic {

    public static void main(String[] args) {
        ArrayList<Integer> number = new ArrayList<>();
        number.add(10);
        number.add(20);
        number.add(30);
        number.add(40);
        number.add(50);
        number.add(60);
        number.add(70);
        number.add(80);
        number.add(90);
        System.out.println(number);
        System.out.println("Size="+number.size());
    }

}
